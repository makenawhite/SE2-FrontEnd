function login() {
    // gets the values 
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // validation
    if (email === "" || password === "") {
      alert("Please enter both an email and a password.");
      return;
    }

    _authController.authenticateUser(email, password, function(){
      window.location.href = "index.html";
    });
  }
