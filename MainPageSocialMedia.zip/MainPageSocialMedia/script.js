
const modal = document.getElementById("create-post-modal");
const createPostButton = document.querySelector("header button");
const closeButton = document.querySelector(".close");

createPostButton.addEventListener("click", () => {
  modal.style.display = "block";
});

closeButton.addEventListener("click", () => {
  modal.style.display = "none";
});

window.addEventListener("click", (event) => {
  if (event.target === modal) {
    modal.style.display = "none";
  }
});

const favoriteButtons = document.querySelectorAll(".favorite-button");
favoriteButtons.forEach((button) => {
  button.addEventListener("click", () => {
    button.classList.toggle("favorite");
    const icon = button.querySelector("i");
    if (icon.textContent === "favorite_border") {
      icon.textContent = "favorite";
    } else {
      icon.textContent = "favorite_border";
    }
  });
});
