function login() {
    // gets the values 
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

    // validation
    if (email === "" || password === "") {
      alert("Please enter both an email and a password.");
      return;
    }

    //write fetch
    // fetch('URL')
    // .then(response => response.json())
    // .then(data => console.log(data))
    // .catch(error => console.error(error));

    console.log("Email: " + email + "\nPassword: " + password);
  }
